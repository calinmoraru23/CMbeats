import { createClient } from '@supabase/supabase-js';

const { SUPABASE_URL, SUPABASE_SERVICE_KEY } = process.env;

export let supabaseAdmin = null;

if (!SUPABASE_URL || !SUPABASE_SERVICE_KEY) {
  console.error("Supabase environment variables are NOT set. Supabase admin client will not be initialized.");
} else {
  try {
    supabaseAdmin = createClient(SUPABASE_URL, SUPABASE_SERVICE_KEY);
    console.log("Supabase admin client initialized successfully.");
  } catch (e) {
    console.error("Error initializing Supabase admin client:", e.message);
    supabaseAdmin = null; // Ensure client is null on error
  }
}