import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import { createOrder, capturePayment } from './paypal.js';
import { supabaseAdmin } from './supabaseAdmin.js';
import { verifyToken } from './authMiddleware.js';

console.log("Serverless function starting up (Express version)!");

// Load local .env if present
dotenv.config();
console.log("Dotenv config loaded.");

const app = express();

app.use(cors());
app.use(express.json()); 
console.log("Express middleware configured.");

// Health check endpoint
app.get('/api', (req, res) => {
  console.log("Health check endpoint hit.");
  res.json({ message: 'API server is running!' });
});

// Endpoint to test environment variables
app.get('/api/test-env', (req, res) => {
  console.log("test-env endpoint hit.");
  res.json({ 
    message: 'Environment variables test',
    SUPABASE_URL_PRESENT: !!process.env.SUPABASE_URL,
    SUPABASE_SERVICE_KEY_PRESENT: !!process.env.SUPABASE_SERVICE_KEY,
    PAYPAL_CLIENT_ID_PRESENT: !!process.env.PAYPAL_CLIENT_ID,
    PAYPAL_CLIENT_SECRET_PRESENT: !!process.env.PAYPAL_CLIENT_SECRET,
    PAYPAL_MODE: process.env.PAYPAL_MODE || 'not set',
    SUPABASE_ADMIN_CLIENT_INITIALIZED: !!supabaseAdmin, // Add check for Supabase client
    PAYPAL_CLIENT_INITIALIZED: !!(createOrder && capturePayment) // Add check for PayPal client
  });
});

// Apply authentication middleware to protected routes
app.use('/api/paypal', verifyToken);
app.use('/api/download', verifyToken);
app.use('/api/purchases', verifyToken);

// PayPal Routes
app.post('/api/paypal/create-order', async (req, res) => {
  console.log("POST /api/paypal/create-order hit.");
  const { beatId, title, price } = req.body;
  const userId = req.user.id; // From verifyToken middleware

  if (!createOrder) {
    console.error("PayPal createOrder function is not available. PayPal client likely failed to initialize.");
    return res.status(500).json({ error: 'PayPal service is not available. Check server logs for environment variable issues.' });
  }

  if (!beatId || !title || !price || !userId) {
    return res.status(400).json({ error: 'Missing required fields for order creation.' });
  }

  try {
    // Create a pending purchase record in Supabase
    const { data: purchase, error: purchaseError } = await supabaseAdmin
      .from('purchases')
      .insert({
        user_id: userId,
        beat_id: beatId,
        amount: price,
        status: 'pending',
      })
      .select()
      .single();

    if (purchaseError) {
      console.error("Supabase error creating pending purchase:", purchaseError);
      return res.status(500).json({ error: purchaseError.message });
    }

    const order = await createOrder(price, title, purchase.id);
    console.log("PayPal order created:", order);
    res.status(200).json({ approvalUrl: order.links.find(link => link.rel === 'approve').href, orderId: order.id, purchaseId: purchase.id });
  } catch (error) {
    console.error("Error creating PayPal order:", error);
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/paypal/capture', async (req, res) => {
  console.log("POST /api/paypal/capture hit.");
  const { paymentId, payerId, purchaseId } = req.body; // paymentId is actually orderId from PayPal
  const userId = req.user.id; // From verifyToken middleware

  if (!capturePayment) {
    console.error("PayPal capturePayment function is not available. PayPal client likely failed to initialize.");
    return res.status(500).json({ error: 'PayPal service is not available. Check server logs for environment variable issues.' });
  }

  if (!paymentId || !purchaseId || !userId) {
    return res.status(400).json({ error: 'Missing required fields for payment capture.' });
  }

  try {
    const capture = await capturePayment(paymentId); // Pass orderId (paymentId from client)
    console.log("PayPal payment capture result:", capture);

    if (capture.status === 'COMPLETED') {
      // Update purchase status in Supabase
      const { error: updateError } = await supabaseAdmin
        .from('purchases')
        .update({ 
          status: 'completed',
          paypal_payment_id: paymentId,
          completed_at: new Date().toISOString(),
          webhook_verified: false // Va fi setat la true de webhook, dar pentru moment presupunem finalizat
        })
        .eq('id', purchaseId)
        .eq('user_id', userId); // Asigură-te că utilizatorul deține achiziția

      if (updateError) {
        console.error("Supabase error updating purchase status:", updateError);
        return res.status(500).json({ error: updateError.message });
      }
      res.status(200).json({ message: 'Payment captured successfully!' });
    } else {
      res.status(400).json({ error: 'Payment not completed.', details: capture });
    }
  } catch (error) {
    console.error("Error capturing PayPal payment:", error);
    res.status(500).json({ error: error.message });
  }
});

// Download Route
app.post('/api/download/generate', async (req, res) => {
  console.log("POST /api/download/generate hit.");
  const { beatId } = req.body;
  const userId = req.user.id; // From verifyToken middleware

  if (!beatId || !userId) {
    return res.status(400).json({ error: 'Missing beatId or userId.' });
  }

  try {
    // Verify if user has purchased this beat
    const { data: purchase, error: purchaseError } = await supabaseAdmin
      .from('purchases')
      .select('id')
      .eq('user_id', userId)
      .eq('beat_id', beatId)
      .eq('status', 'completed')
      .single();

    if (purchaseError || !purchase) {
      console.warn(`User ${userId} attempted to download unpurchased beat ${beatId}.`);
      return res.status(403).json({ error: 'You have not purchased this beat.' });
    }

    // Generate signed URL for private beat file
    const { data, error: storageError } = await supabaseAdmin.storage
      .from('beats')
      .createSignedUrl(`private/${beatId}.wav`, 3600); // Expiră în 1 oră

    if (storageError) {
      console.error("Supabase storage error generating signed URL:", storageError);
      return res.status(500).json({ error: storageError.message });
    }

    // Record download
    await supabaseAdmin.from('downloads').insert({
      purchase_id: purchase.id,
      user_id: userId,
      beat_id: beatId,
    });

    res.status(200).json({ downloadUrl: data.signedUrl });
  } catch (error) {
    console.error("Error generating download link:", error);
    res.status(500).json({ error: error.message });
  }
});

// Check Purchase Route
app.get('/api/purchases/:beatId', async (req, res) => {
  console.log(`GET /api/purchases/${req.params.beatId} hit.`);
  const { beatId } = req.params;
  const userId = req.user.id; // From verifyToken middleware

  if (!beatId || !userId) {
    return res.status(400).json({ error: 'Missing beatId or userId.' });
  }

  try {
    const { data, error } = await supabaseAdmin
      .from('purchases')
      .select('id')
      .eq('user_id', userId)
      .eq('beat_id', beatId)
      .eq('status', 'completed')
      .single();

    if (error && error.code !== 'PGRST116') { // PGRST116 înseamnă "no rows found"
      console.error("Supabase error checking purchase:", error);
      return res.status(500).json({ error: error.message });
    }

    res.status(200).json({ hasPurchased: !!data });
  } catch (error) {
    console.error("Error checking purchase:", error);
    res.status(500).json({ error: error.message });
  }
});


// Global error handler
app.use((err, req, res, next) => {
  console.error("Unhandled server error in Express app:", err);
  if (res.headersSent) {
    return next(err);
  }
  res.status(500).json({ 
    error: "An unexpected server error occurred in Express app", 
    details: err.message 
  });
});

console.log("Express app configured and exported.");
export default app;