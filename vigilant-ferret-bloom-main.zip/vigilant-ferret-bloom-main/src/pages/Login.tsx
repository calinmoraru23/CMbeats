"use client";

import React, { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Music, Shield } from 'lucide-react';
import { showSuccess } from '@/utils/toast';

const Login = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { signIn, loading } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const beatId = location.state?.beatId;

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    
    const success = await signIn(email, password);
    if (success) {
      navigate('/');
    }
  };

  const handleAdminLogin = async () => {
    // This is a helper for testing - in a real app, you'd use a proper admin login flow
    // For now, we'll just show a message and let the user know to log in manually
    showSuccess('Please log in manually with your admin email: calin_moraru@yahoo.com');
    setEmail('calin_moraru@yahoo.com');
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center space-y-2">
          <div className="flex justify-center mb-2">
            <Music className="h-8 w-8 text-primary" />
          </div>
          <CardTitle className="text-2xl">Welcome Back</CardTitle>
          <CardDescription>
            Log in to continue
            {beatId && <span className="block text-xs mt-1 text-muted-foreground">You'll be redirected back after login</span>}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleLogin} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input 
                id="email" 
                type="email" 
                placeholder="you@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <Input 
                id="password" 
                type="password" 
                placeholder="Min. 6 characters"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </div>
            <Button type="submit" className="w-full" disabled={loading}>
              {loading ? 'Logging in...' : 'Log In'}
            </Button>
            <div className="text-center text-sm">
              <button 
                type="button"
                onClick={() => navigate('/signup', { state: { beatId } })}
                className="text-primary hover:underline"
              >
                Don't have an account? Sign up
              </button>
            </div>
          </form>
          
          {/* Admin Login Helper */}
          <div className="mt-6 pt-6 border-t">
            <Button 
              onClick={handleAdminLogin} 
              variant="outline" 
              className="w-full gap-2"
            >
              <Shield className="h-4 w-4" />
              Login as Admin
            </Button>
            <p className="text-xs text-center text-muted-foreground mt-2">
              Click here if you are the admin and need to manage categories
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default Login;