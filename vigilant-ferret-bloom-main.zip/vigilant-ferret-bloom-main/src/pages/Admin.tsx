"use client";

import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';
import Navbar from '@/components/Navbar';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { 
  Plus, 
  Settings, 
  Trash2, 
  Upload, 
  GripVertical,
  X,
  Save,
  Loader2
} from 'lucide-react';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { showSuccess, showError } from '@/utils/toast';
import { supabase } from '@/lib/supabase';
import CategoryManagement from '@/components/CategoryManagement';

const ADMIN_EMAIL = 'calin_moraru@yahoo.com';

interface Beat {
  id: string;
  title: string;
  producer: string;
  category: string;
  price: number;
  cover: string | null;
  audiourl: string;
  order: number;
  created_at: string;
}

interface Category {
  id: string;
  name: string;
  order_index: number;
}

const AdminDashboard = () => {
  const navigate = useNavigate();
  const { user, loading: authLoading } = useAuth();
  const [beats, setBeats] = useState<Beat[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [isUploading, setIsUploading] = useState(false);
  
  // Edit modal state
  const [editingBeat, setEditingBeat] = useState<Beat | null>(null);
  const [editFormData, setEditFormData] = useState({
    title: '',
    producer: '',
    category: '',
    price: 0,
    cover: '',
  });

  // Upload form state
  const [uploadData, setUploadData] = useState({
    title: '',
    producer: 'CM Beats',
    category: '',
    price: 29.99,
    cover: '',
  });
  const [wavFile, setWavFile] = useState<File | null>(null);

  // Verificare admin
  useEffect(() => {
    if (!authLoading && user?.email !== ADMIN_EMAIL) {
      showError('Acces interzis. Doar administratorul poate accesa această pagină.');
      navigate('/');
    }
  }, [user, authLoading, navigate]);

  // Încarcă piesele și categoriile
  useEffect(() => {
    if (user?.email === ADMIN_EMAIL) {
      loadData();
    }
  }, [user]);

  const loadData = async () => {
    setLoading(true);
    
    // Încarcă piesele
    const { data: beatsData, error: beatsError } = await supabase
      .from('beats')
      .select('*')
      .order('order', { ascending: true });

    // Încarcă categoriile
    const { data: categoriesData, error: categoriesError } = await supabase
      .from('categories')
      .select('id, name, order_index')
      .order('order_index', { ascending: true });

    if (beatsError) {
      showError('Nu am putut încărca piesele: ' + beatsError.message);
    } else {
      setBeats(beatsData || []);
    }

    if (categoriesError) {
      showError('Nu am putut încărca categoriile: ' + categoriesError.message);
    } else {
      setCategories(categoriesData || []);
    }

    setLoading(false);
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.type !== 'audio/wav' && !file.name.toLowerCase().endsWith('.wav')) {
      showError('Doar fișierele .WAV sunt acceptate!');
      return;
    }

    setWavFile(file);
    showSuccess(`Fișier selectat: ${file.name}`);
  };

  const handleUpload = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!wavFile) {
      showError('Te rog selectează un fișier WAV');
      return;
    }

    if (!uploadData.category) {
      showError('Te rog selectează o categorie');
      return;
    }

    setIsUploading(true);
    const beatId = `beat_${Date.now()}`;

    try {
      // 1. Upload WAV în Supabase Storage
      const { error: uploadError } = await supabase.storage
        .from('beats')
        .upload(`private/${beatId}.wav`, wavFile, {
          contentType: 'audio/wav',
          upsert: false,
        });

      if (uploadError) throw uploadError;

      // 2. Obține URL public (pentru player)
      const { data: urlData } = await supabase.storage
        .from('beats')
        .getPublicUrl(`private/${beatId}.wav`);

      // 3. Calculează următorul ordin
      const nextOrder = beats.length > 0 ? Math.max(...beats.map(b => b.order)) + 1 : 1;

      // 4. Salvează înregistrarea în tabelă
      const coverValue = uploadData.cover.trim() === '' ? '' : uploadData.cover;

      const { error: dbError } = await supabase
        .from('beats')
        .insert({
          id: beatId,
          title: uploadData.title,
          producer: uploadData.producer,
          category: uploadData.category,
          price: uploadData.price,
          cover: coverValue,
          audiourl: urlData.publicUrl, 
          order: nextOrder,
        });

      if (dbError) throw dbError;

      showSuccess('Piesa a fost încărcată cu succes!');
      
      // Reset form
      setUploadData({ title: '', producer: 'CM Beats', category: '', price: 29.99, cover: '' });
      setWavFile(null);
      loadData(); // Reîncarcă datele

    } catch (error) {
      console.error('Upload error:', error);
      showError('Eroare la upload: ' + error.message);
    } finally {
      setIsUploading(false);
    }
  };

  const handleDragStart = (e: React.DragEvent<HTMLTableRowElement>, index: number) => {
    e.dataTransfer.setData('text/plain', index.toString());
    e.currentTarget.style.opacity = '0.5';
  };

  const handleDragOver = (e: React.DragEvent<HTMLTableRowElement>) => {
    e.preventDefault();
    e.currentTarget.style.backgroundColor = '#f0f9ff';
  };

  const handleDragLeave = (e: React.DragEvent<HTMLTableRowElement>) => {
    e.currentTarget.style.backgroundColor = '';
  };

  const handleDrop = async (e: React.DragEvent<HTMLTableRowElement>, targetIndex: number) => {
    e.preventDefault();
    e.currentTarget.style.backgroundColor = '';

    const sourceIndex = parseInt(e.dataTransfer.getData('text/plain'));
    
    if (sourceIndex === targetIndex) return;

    // Reordonează array-ul local
    const newBeats = [...beats];
    const [movedItem] = newBeats.splice(sourceIndex, 1);
    newBeats.splice(targetIndex, 0, movedItem);

    // Actualizează valorile order
    const updatedBeats = newBeats.map((beat, index) => ({
      ...beat,
      order: index + 1,
    }));

    setBeats(updatedBeats);

    // Actualizează în baza de date
    const { error } = await supabase
      .from('beats')
      .upsert(
        updatedBeats.map(beat => ({
          id: beat.id,
          order: beat.order,
        }))
      );

    if (error) {
      showError('Eroare la actualizarea ordinii: ' + error.message);
      loadData(); // Reîncarcă datele originale
    } else {
      showSuccess('Ordinea a fost actualizată!');
    }
  };

  const handleEdit = (beat: Beat) => {
    setEditingBeat(beat);
    setEditFormData({
      title: beat.title,
      producer: beat.producer,
      category: beat.category,
      price: beat.price,
      cover: beat.cover || '',
    });
  };

  const handleSaveEdit = async () => {
    if (!editingBeat) return;

    const updatedCover = editFormData.cover.trim() === '' ? '' : editFormData.cover;

    const { error } = await supabase
      .from('beats')
      .update({ ...editFormData, cover: updatedCover })
      .eq('id', editingBeat.id);

    if (error) {
      showError('Eroare la salvare: ' + error.message);
      return;
    }

    showSuccess('Piesa a fost actualizată!');
    setEditingBeat(null);
    loadData();
  };

  const handleDelete = async (beatId: string) => {
    if (!confirm('Ești sigur că vrei să ștergi această piesă? Aceasta va șterge și fișierul .wav de pe server.')) return;

    try {
      const filePath = `private/${beatId}.wav`;

      const { error: storageError } = await supabase.storage
        .from('beats')
        .remove([filePath]);

      if (storageError && !storageError.message.includes('not found')) {
        throw storageError;
      }

      const { error: dbError } = await supabase
        .from('beats')
        .delete()
        .eq('id', beatId);

      if (dbError) throw dbError;

      showSuccess('Piesa a fost ștearsă cu succes din toate sursele!');
      loadData();

    } catch (error) {
      console.error('Delete error:', error);
      showError('Eroare la ștergere: ' + error.message);
    }
  };

  if (authLoading || user?.email !== ADMIN_EMAIL) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background pb-8">
      <Navbar />
      
      <main className="container py-8 px-4">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
          <div>
            <h1 className="text-3xl font-bold">Admin Dashboard</h1>
            <p className="text-muted-foreground">
              {user?.email} • Gestionează beat-urile, categoriile și licențele
            </p>
          </div>
        </div>

        {/* Category Management Section */}
        <CategoryManagement />

        {/* Upload Section */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Upload className="h-5 w-5" />
              Încarcă Beat Nou
            </CardTitle>
            <CardDescription>
              Adaugă un nou beat WAV în colecție
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleUpload} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Titlu</Label>
                  <Input 
                    placeholder="Ex: Midnight Rain"
                    value={uploadData.title}
                    onChange={(e) => setUploadData({...uploadData, title: e.target.value})}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label>Producător</Label>
                  <Input 
                    placeholder="Ex: CM Beats"
                    value={uploadData.producer}
                    onChange={(e) => setUploadData({...uploadData, producer: e.target.value})}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label>Categorie</Label>
                  <Select 
                    value={uploadData.category} 
                    onValueChange={(value) => setUploadData({...uploadData, category: value})}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Selectează o categorie" />
                    </SelectTrigger>
                    <SelectContent>
                      {categories.map((cat) => (
                        <SelectItem key={cat.id} value={cat.name}>
                          {cat.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Preț (USD)</Label>
                  <Input 
                    type="number"
                    step="0.01"
                    value={uploadData.price}
                    onChange={(e) => setUploadData({...uploadData, price: parseFloat(e.target.value)})}
                    required
                  />
                </div>
                <div className="space-y-2 md:col-span-2">
                  <Label>Link Cover (opțional)</Label>
                  <Input 
                    placeholder="https://..."
                    value={uploadData.cover}
                    onChange={(e) => setUploadData({...uploadData, cover: e.target.value})}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label>Fisier WAV</Label>
                <Input 
                  type="file"
                  accept=".wav,audio/wav"
                  onChange={handleFileSelect}
                  required
                />
                <p className="text-xs text-muted-foreground">
                  Doar fișiere .WAV sunt acceptate
                </p>
              </div>

              <Button 
                type="submit" 
                disabled={isUploading || !wavFile || !uploadData.title || !uploadData.category}
                className="gap-2"
              >
                {isUploading ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <Plus className="h-4 w-4" />
                )}
                {isUploading ? 'Se încarcă...' : 'Încarcă Beat'}
              </Button>
            </form>
          </CardContent>
        </Card>

        {/* Beats List */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle>Beat-uri Încărcate</CardTitle>
            <span className="text-sm text-muted-foreground">
              {beats.length} piese • Trage pentru a reordona
            </span>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="flex justify-center py-8">
                <Loader2 className="h-8 w-8 animate-spin" />
              </div>
            ) : beats.length === 0 ? (
              <p className="text-center py-8 text-muted-foreground">
                Nu există beat-uri încărcate încă.
              </p>
            ) : (
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-12"></TableHead>
                      <TableHead>Ordine</TableHead>
                      <TableHead>Titlu</TableHead>
                      <TableHead>Categorie</TableHead>
                      <TableHead>Preț</TableHead>
                      <TableHead className="text-right">Acțiuni</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {beats.map((beat, index) => (
                      <TableRow 
                        key={beat.id}
                        draggable
                        onDragStart={(e) => handleDragStart(e, index)}
                        onDragOver={handleDragOver}
                        onDragLeave={handleDragLeave}
                        onDrop={(e) => handleDrop(e, index)}
                        className="cursor-move hover:bg-accent/50"
                      >
                        <TableCell>
                          <GripVertical className="h-4 w-4 text-muted-foreground" />
                        </TableCell>
                        <TableCell className="font-mono">{beat.order}</TableCell>
                        <TableCell className="font-medium">{beat.title}</TableCell>
                        <TableCell>{beat.category}</TableCell>
                        <TableCell>${beat.price}</TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end gap-2">
                            <Button 
                              variant="ghost" 
                              size="icon"
                              onClick={() => handleEdit(beat)}
                            >
                              <Settings className="h-4 w-4" />
                            </Button>
                            <Button 
                              variant="ghost" 
                              size="icon"
                              onClick={() => handleDelete(beat.id)}
                              className="text-red-500 hover:text-red-700"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Edit Dialog */}
        <Dialog open={!!editingBeat} onOpenChange={(open) => !open && setEditingBeat(null)}>
          <DialogContent className="sm:max-w-[425px]">
            <DialogHeader>
              <DialogTitle>Editează Piesa</DialogTitle>
              <DialogDescription>
                Modifică detaliile piesei și salvează modificările.
              </DialogDescription>
            </DialogHeader>
            {editingBeat && (
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label>Titlu</Label>
                  <Input 
                    value={editFormData.title}
                    onChange={(e) => setEditFormData({...editFormData, title: e.target.value})}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Producător</Label>
                  <Input 
                    value={editFormData.producer}
                    onChange={(e) => setEditFormData({...editFormData, producer: e.target.value})}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Categorie</Label>
                  <Select 
                    value={editFormData.category} 
                    onValueChange={(value) => setEditFormData({...editFormData, category: value})}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Selectează o categorie" />
                    </SelectTrigger>
                    <SelectContent>
                      {categories.map((cat) => (
                        <SelectItem key={cat.id} value={cat.name}>
                          {cat.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Preț</Label>
                  <Input 
                    type="number"
                    step="0.01"
                    value={editFormData.price}
                    onChange={(e) => setEditFormData({...editFormData, price: parseFloat(e.target.value)})}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Cover URL</Label>
                  <Input 
                    value={editFormData.cover}
                    onChange={(e) => setEditFormData({...editFormData, cover: e.target.value})}
                  />
                </div>
              </div>
            )}
            <DialogFooter>
              <Button variant="outline" onClick={() => setEditingBeat(null)}>
                Anulează
              </Button>
              <Button onClick={handleSaveEdit} className="gap-2">
                <Save className="h-4 w-4" />
                Salvează
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </main>
    </div>
  );
};

export default AdminDashboard;