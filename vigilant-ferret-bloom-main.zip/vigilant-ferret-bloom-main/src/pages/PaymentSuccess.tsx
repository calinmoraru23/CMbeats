"use client";

import React, { useEffect, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { usePayPal } from '@/hooks/usePayPal';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { CheckCircle, Loader2, Download } from 'lucide-react';
import { showSuccess, showError } from '@/utils/toast';

const PaymentSuccess = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const { capturePayPalPayment, getDownloadLink, loading } = usePayPal();
  const [status, setStatus] = useState<'processing' | 'success' | 'error'>('processing');
  const [downloadUrl, setDownloadUrl] = useState<string | null>(null);

  useEffect(() => {
    const processPayment = async () => {
      const paymentId = searchParams.get('paymentId');
      const payerId = searchParams.get('PayerID');
      const purchaseId = localStorage.getItem('pendingPurchaseId');

      if (!paymentId || !payerId || !purchaseId) {
        showError('Invalid payment data');
        setStatus('error');
        return;
      }

      // Capturare plată
      const success = await capturePayPalPayment(paymentId, payerId, purchaseId);

      if (success) {
        setStatus('success');
        
        // Generare link download
        const beatId = localStorage.getItem('pendingBeatId');
        if (beatId) {
          const url = await getDownloadLink(beatId);
          if (url) {
            setDownloadUrl(url);
            localStorage.removeItem('pendingPurchaseId');
            localStorage.removeItem('pendingBeatId');
          }
        }
      } else {
        setStatus('error');
      }
    };

    processPayment();
  }, [searchParams, capturePayPalPayment, getDownloadLink]);

  const handleDownload = () => {
    if (downloadUrl) {
      window.open(downloadUrl, '_blank');
      showSuccess('Download started!');
      navigate('/');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          {status === 'processing' && (
            <Loader2 className="h-12 w-12 mx-auto text-blue-500 animate-spin mb-4" />
          )}
          {status === 'success' && (
            <CheckCircle className="h-12 w-12 mx-auto text-green-500 mb-4" />
          )}
          {status === 'error' && (
            <div className="text-red-500 text-4xl mb-4">⚠️</div>
          )}
          
          <CardTitle className="text-2xl">
            {status === 'processing' && 'Processing Payment...'}
            {status === 'success' && 'Payment Successful!'}
            {status === 'error' && 'Payment Failed'}
          </CardTitle>
        </CardHeader>
        
        <CardContent className="text-center space-y-4">
          {status === 'processing' && (
            <p className="text-muted-foreground">Please wait while we confirm your payment...</p>
          )}
          
          {status === 'success' && (
            <>
              <p className="text-muted-foreground">
                Your beat license has been activated!
              </p>
              {downloadUrl && (
                <Button 
                  onClick={handleDownload} 
                  className="w-full gap-2"
                  size="lg"
                >
                  <Download className="h-5 w-5" />
                  Download Your Beat
                </Button>
              )}
              <Button 
                variant="outline" 
                onClick={() => navigate('/')}
                className="w-full"
              >
                Back to Home
              </Button>
            </>
          )}
          
          {status === 'error' && (
            <>
              <p className="text-muted-foreground">
                There was an issue processing your payment. Please try again.
              </p>
              <Button 
                onClick={() => navigate('/')}
                className="w-full"
              >
                Return Home
              </Button>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default PaymentSuccess;