"use client";

import React from 'react';
import { Play } from 'lucide-react';
import { Card, CardContent, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import PurchaseButton from './PurchaseButton';

interface Beat {
  id: string;
  title: string;
  producer: string;
  category: string; // Added 'category' property
  price: number;
  cover: string | null; // Allow cover to be null
  audiourl: string;
  order: number; // Added 'order' property
}

interface BeatCardProps {
  beat: Beat;
  onPlay: (beat: Beat) => void;
}

const BeatCard = ({ beat, onPlay }: BeatCardProps) => {
  const imageUrl = beat.cover || 'https://images.unsplash.com/photo-1614613535308-eb5fbd3d2c17?w=800';

  return (
    <Card className="overflow-hidden group hover:shadow-lg transition-shadow bg-card">
      <div className="relative aspect-square">
        <img 
          src={imageUrl} 
          alt={beat.title} 
          className="object-cover w-full h-full transition-transform group-hover:scale-105"
        />
        <div className="absolute inset-0 bg-black/40 flex items-center justify-center"> {/* Removed opacity-0 group-hover:opacity-100 */}
          <Button 
            onClick={() => onPlay(beat)} 
            size="icon" 
            className="rounded-full w-12 h-12 bg-primary text-primary-foreground hover:scale-110 transition-transform"
          >
            <Play className="h-6 w-6 fill-current" />
          </Button>
        </div>
        <Badge className="absolute top-2 right-2 bg-black/60 backdrop-blur-sm border-none">
          {beat.category}
        </Badge>
      </div>
      <CardContent className="p-4">
        <h3 className="font-bold text-lg truncate">{beat.title}</h3>
        <p className="text-sm text-muted-foreground truncate">prod. {beat.producer}</p>
      </CardContent>
      <CardFooter className="p-4 pt-0 flex justify-between items-center">
        <span className="font-bold text-lg">${beat.price}</span>
        <PurchaseButton beat={beat} variant="outline" />
      </CardFooter>
    </Card>
  );
};

export default BeatCard;