"use client";

import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';
import { usePayPal } from '@/hooks/usePayPal';
import { Button } from '@/components/ui/button';
import { Download, CheckCircle, Loader2, CreditCard } from 'lucide-react';
import { showSuccess, showError } from '@/utils/toast';

interface Beat {
  id: string;
  title: string;
  producer: string;
  price: number;
  cover: string;
  audiourl: string;
  category: string; // Added 'category' property
  order: number; // Added 'order' property
}

interface PurchaseButtonProps {
  beat: Beat;
  variant?: 'default' | 'outline' | 'secondary';
  size?: 'default' | 'sm' | 'icon';
}

const PurchaseButton = ({ beat, variant = 'secondary', size = 'sm' }: PurchaseButtonProps) => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { createPayPalOrder, getDownloadLink, checkPurchase, loading } = usePayPal();
  const [hasPurchased, setHasPurchased] = useState(false);
  const [isChecking, setIsChecking] = useState(true);

  useEffect(() => {
    const check = async () => {
      if (user) {
        const purchased = await checkPurchase(beat.id);
        setHasPurchased(purchased);
      }
      setIsChecking(false);
    };
    check();
  }, [user, beat.id, checkPurchase]);

  const handleAction = async () => {
    if (!user) {
      localStorage.setItem('currentBeat', JSON.stringify(beat));
      navigate('/signup', { state: { beatId: beat.id } });
      showError('Please sign up to purchase this beat.');
      return;
    }

    if (hasPurchased) {
      // Already purchased - download
      const downloadLink = await getDownloadLink(beat.id);
      if (downloadLink) {
        window.open(downloadLink, '_blank');
        showSuccess(`Download started for ${beat.title}!`);
      }
      return;
    }

    // New purchase - PayPal flow
    const order = await createPayPalOrder(beat);
    if (order) {
      // Store for return URL
      localStorage.setItem('pendingPurchaseId', order.purchaseId);
      localStorage.setItem('pendingBeatId', beat.id);
    }
  };

  if (isChecking) {
    return (
      <Button variant={variant} size={size} disabled>
        <Loader2 className="h-4 w-4 animate-spin" />
      </Button>
    );
  }

  if (hasPurchased) {
    return (
      <Button 
        variant="default" 
        size={size} 
        onClick={handleAction}
        className="gap-2 bg-green-600 hover:bg-green-700"
      >
        <Download className="h-4 w-4" />
        Download
      </Button>
    );
  }

  return (
    <Button 
      variant={variant} 
      size={size} 
      onClick={handleAction}
      disabled={loading}
      className="gap-2"
    >
      {loading ? (
        <Loader2 className="h-4 w-4 animate-spin" />
      ) : (
        <CreditCard className="h-4 w-4" />
      )}
      {loading ? 'Processing...' : 'License & Download'}
    </Button>
  );
};

export default PurchaseButton;