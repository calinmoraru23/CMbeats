"use client";

import React from 'react';
import { Card } from '@/components/ui/card';
import { cn } from '@/lib/utils';

interface CategoryCardProps {
  name: string;
  image: string;
  onClick: () => void;
}

const CategoryCard = ({ name, image, onClick }: CategoryCardProps) => {
  return (
    <Card 
      onClick={onClick}
      className="group relative aspect-[4/3] overflow-hidden cursor-pointer border-none"
    >
      <img 
        src={image} 
        alt={name} 
        className="object-cover w-full h-full transition-transform duration-500 group-hover:scale-110"
      />
      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent flex items-end p-6">
        <h3 className="text-2xl font-bold text-white tracking-tight">{name}</h3>
      </div>
    </Card>
  );
};

export default CategoryCard;