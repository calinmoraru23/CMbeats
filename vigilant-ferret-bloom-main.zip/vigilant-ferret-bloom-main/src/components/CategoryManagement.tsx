"use client";

import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { showError, showSuccess } from '@/utils/toast';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Plus, Settings, Trash2, GripVertical, Loader2, Save, X } from 'lucide-react';

interface Category {
  id: string;
  name: string;
  image_url: string | null;
  order_index: number;
}

const CategoryManagement = () => {
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [isUploadingImage, setIsUploadingImage] = useState(false);

  // Add/Edit dialog state
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [currentCategory, setCurrentCategory] = useState<Category | null>(null);
  const [categoryName, setCategoryName] = useState('');
  const [categoryImageFile, setCategoryImageFile] = useState<File | null>(null);
  const [categoryImageUrl, setCategoryImageUrl] = useState<string | null>(null);

  useEffect(() => {
    loadCategories();
  }, []);

  const loadCategories = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('categories')
      .select('*')
      .order('order_index', { ascending: true });

    if (error) {
      showError('Failed to load categories: ' + error.message);
      setCategories([]);
    } else {
      setCategories(data || []);
    }
    setLoading(false);
  };

  const handleImageFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setCategoryImageFile(file);
      setCategoryImageUrl(URL.createObjectURL(file)); // Preview image
    } else {
      setCategoryImageFile(null);
      setCategoryImageUrl(currentCategory?.image_url || null);
    }
  };

  const handleAddCategory = () => {
    setCurrentCategory(null);
    setCategoryName('');
    setCategoryImageFile(null);
    setCategoryImageUrl(null);
    setIsDialogOpen(true);
  };

  const handleEditCategory = (category: Category) => {
    setCurrentCategory(category);
    setCategoryName(category.name);
    setCategoryImageFile(null); // Clear file input for edit
    setCategoryImageUrl(category.image_url);
    setIsDialogOpen(true);
  };

  const handleSaveCategory = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!categoryName.trim()) {
      showError('Category name cannot be empty.');
      return;
    }

    setIsUploadingImage(true);
    let newImageUrl = categoryImageUrl;

    try {
      if (categoryImageFile) {
        const filePath = `public/${Date.now()}_${categoryImageFile.name}`;
        const { data: uploadData, error: uploadError } = await supabase.storage
          .from('category-covers')
          .upload(filePath, categoryImageFile, {
            cacheControl: '3600',
            upsert: true,
          });

        if (uploadError) throw uploadError;

        const { data: publicUrlData } = supabase.storage
          .from('category-covers')
          .getPublicUrl(filePath);
        
        newImageUrl = publicUrlData.publicUrl;

        // If editing and changing image, delete old image from storage
        if (currentCategory?.image_url && currentCategory.image_url !== newImageUrl) {
          const oldFilePath = currentCategory.image_url.split('category-covers/')[1];
          await supabase.storage.from('category-covers').remove([oldFilePath]);
        }

      } else if (currentCategory && !categoryImageUrl) {
        // If editing and image was removed
        if (currentCategory.image_url) {
          const oldFilePath = currentCategory.image_url.split('category-covers/')[1];
          await supabase.storage.from('category-covers').remove([oldFilePath]);
        }
        newImageUrl = null;
      }

      if (currentCategory) {
        // Update existing category
        const { error } = await supabase
          .from('categories')
          .update({ name: categoryName, image_url: newImageUrl })
          .eq('id', currentCategory.id);

        if (error) throw error;
        showSuccess('Category updated successfully!');
      } else {
        // Add new category
        const nextOrder = categories.length > 0 ? Math.max(...categories.map(c => c.order_index)) + 1 : 1;
        const { error } = await supabase
          .from('categories')
          .insert({ name: categoryName, image_url: newImageUrl, order_index: nextOrder });

        if (error) throw error;
        showSuccess('Category added successfully!');
      }

      setIsDialogOpen(false);
      loadCategories();
    } catch (error) {
      console.error('Error saving category:', error);
      showError('Failed to save category: ' + error.message);
    } finally {
      setIsUploadingImage(false);
    }
  };

  const handleDeleteCategory = async (categoryId: string, imageUrl: string | null) => {
    if (!confirm('Are you sure you want to delete this category?')) return;

    try {
      // Delete image from storage if it exists
      if (imageUrl) {
        const filePath = imageUrl.split('category-covers/')[1];
        if (filePath) {
          const { error: storageError } = await supabase.storage
            .from('category-covers')
            .remove([filePath]);
          if (storageError) console.error('Error deleting category image from storage:', storageError);
        }
      }

      // Delete category from database
      const { error: dbError } = await supabase
        .from('categories')
        .delete()
        .eq('id', categoryId);

      if (dbError) throw dbError;

      showSuccess('Category deleted successfully!');
      loadCategories();
    } catch (error) {
      console.error('Error deleting category:', error);
      showError('Failed to delete category: ' + error.message);
    }
  };

  const handleDragStart = (e: React.DragEvent<HTMLTableRowElement>, index: number) => {
    e.dataTransfer.setData('text/plain', index.toString());
    e.currentTarget.style.opacity = '0.5';
  };

  const handleDragOver = (e: React.DragEvent<HTMLTableRowElement>) => {
    e.preventDefault();
    e.currentTarget.style.backgroundColor = '#f0f9ff';
  };

  const handleDragLeave = (e: React.DragEvent<HTMLTableRowElement>) => {
    e.currentTarget.style.backgroundColor = '';
  };

  const handleDrop = async (e: React.DragEvent<HTMLTableRowElement>, targetIndex: number) => {
    e.preventDefault();
    e.currentTarget.style.backgroundColor = '';

    const sourceIndex = parseInt(e.dataTransfer.getData('text/plain'));
    
    if (sourceIndex === targetIndex) return;

    const newCategories = [...categories];
    const [movedItem] = newCategories.splice(sourceIndex, 1);
    newCategories.splice(targetIndex, 0, movedItem);

    const updatedCategories = newCategories.map((cat, index) => ({
      ...cat,
      order_index: index + 1,
    }));

    setCategories(updatedCategories);

    const { error } = await supabase
      .from('categories')
      .upsert(
        updatedCategories.map(cat => ({
          id: cat.id,
          order_index: cat.order_index,
        }))
      );

    if (error) {
      showError('Failed to update category order: ' + error.message);
      loadCategories();
    } else {
      showSuccess('Category order updated!');
    }
  };

  return (
    <Card className="mb-8">
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="flex items-center gap-2">
          <Settings className="h-5 w-5" />
          Manage Categories
        </CardTitle>
        <Button onClick={handleAddCategory} className="gap-2">
          <Plus className="h-4 w-4" />
          Add Category
        </Button>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="flex justify-center py-8">
            <Loader2 className="h-8 w-8 animate-spin" />
          </div>
        ) : categories.length === 0 ? (
          <p className="text-center py-8 text-muted-foreground">
            No categories found. Click "Add Category" to create one.
          </p>
        ) : (
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-12"></TableHead>
                  <TableHead>Order</TableHead>
                  <TableHead>Name</TableHead>
                  <TableHead>Image</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {categories.map((category, index) => (
                  <TableRow
                    key={category.id}
                    draggable
                    onDragStart={(e) => handleDragStart(e, index)}
                    onDragOver={handleDragOver}
                    onDragLeave={handleDragLeave}
                    onDrop={(e) => handleDrop(e, index)}
                    className="cursor-move hover:bg-accent/50"
                  >
                    <TableCell>
                      <GripVertical className="h-4 w-4 text-muted-foreground" />
                    </TableCell>
                    <TableCell className="font-mono">{category.order_index}</TableCell>
                    <TableCell className="font-medium">{category.name}</TableCell>
                    <TableCell>
                      {category.image_url ? (
                        <img src={category.image_url} alt={category.name} className="w-10 h-10 object-cover rounded" />
                      ) : (
                        <span className="text-muted-foreground text-sm">No Image</span>
                      )}
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleEditCategory(category)}
                        >
                          <Settings className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleDeleteCategory(category.id, category.image_url)}
                          className="text-red-500 hover:text-red-700"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>

      {/* Add/Edit Category Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>{currentCategory ? 'Edit Category' : 'Add New Category'}</DialogTitle>
            <DialogDescription>
              {currentCategory ? 'Modify category details.' : 'Create a new category.'}
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSaveCategory} className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="categoryName">Category Name</Label>
              <Input
                id="categoryName"
                value={categoryName}
                onChange={(e) => setCategoryName(e.target.value)}
                placeholder="e.g., Hip-Hop"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="categoryImage">Category Image</Label>
              <Input
                id="categoryImage"
                type="file"
                accept="image/*"
                onChange={handleImageFileSelect}
              />
              {categoryImageUrl && (
                <div className="relative w-24 h-24 mt-2">
                  <img src={categoryImageUrl} alt="Category Preview" className="w-full h-full object-cover rounded" />
                  <Button 
                    type="button"
                    variant="destructive" 
                    size="icon" 
                    className="absolute -top-2 -right-2 h-6 w-6 rounded-full"
                    onClick={() => {
                      setCategoryImageFile(null);
                      setCategoryImageUrl(null);
                    }}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              )}
              <p className="text-xs text-muted-foreground">
                Upload an image for the category card.
              </p>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsDialogOpen(false)} type="button">
                Cancel
              </Button>
              <Button type="submit" disabled={isUploadingImage || !categoryName.trim()} className="gap-2">
                {isUploadingImage ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <Save className="h-4 w-4" />
                )}
                {isUploadingImage ? 'Saving...' : 'Save Category'}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </Card>
  );
};

export default CategoryManagement;