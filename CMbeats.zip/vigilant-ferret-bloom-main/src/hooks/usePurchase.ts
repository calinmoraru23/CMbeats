"use client";

import { useState } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { showSuccess, showError, showLoading } from '@/utils/toast';
import { supabase } from '@/lib/supabase';

interface Beat {
  id: string;
  title: string;
  price: number;
  audioUrl: string;
}

export const usePurchase = () => {
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);

  // Check if user has already purchased a beat
  const checkPurchase = async (beatId: string): Promise<boolean> => {
    if (!user) return false;

    const { data, error } = await supabase
      .from('purchases')
      .select('id')
      .eq('user_id', user.id)
      .eq('beat_id', beatId)
      .eq('status', 'completed')
      .single();

    return !!data && !error;
  };

  // Create purchase record (before payment)
  const createPurchase = async (beat: Beat) => {
    if (!user) {
      showError('You must be logged in to purchase');
      return null;
    }

    const { data, error } = await supabase
      .from('purchases')
      .insert({
        user_id: user.id,
        beat_id: beat.id,
        amount: beat.price,
        status: 'pending',
      })
      .select()
      .single();

    if (error) {
      showError(error.message);
      return null;
    }

    return data;
  };

  // Update purchase status after payment
  const completePurchase = async (purchaseId: string) => {
    const { error } = await supabase
      .from('purchases')
      .update({ 
        status: 'completed',
        completed_at: new Date().toISOString(),
      })
      .eq('id', purchaseId);

    if (error) {
      showError(error.message);
      return false;
    }

    return true;
  };

  // Generate secure download link (time-limited)
  const generateDownloadLink = async (beat: Beat): Promise<string | null> => {
    if (!user) return null;

    // Create a signed URL that expires in 24 hours
    const { data, error } = await supabase.storage
      .from('beats')
      .createSignedUrl(`private/${beat.id}.wav`, 86400); // 24 hours

    if (error) {
      showError(error.message);
      return null;
    }

    return data.signedUrl;
  };

  // Simulate PayPal payment flow
  const initiatePayPalPayment = async (beat: Beat) => {
    if (!user) {
      showError('Please log in to purchase');
      return;
    }

    setLoading(true);
    const toastId = showLoading('Processing payment...');

    // Create purchase record
    const purchase = await createPurchase(beat);
    if (!purchase) {
      setLoading(false);
      return;
    }

    // In production, this would redirect to PayPal
    // For now, we simulate successful payment after 2 seconds
    setTimeout(async () => {
      const success = await completePurchase(purchase.id);
      
      if (success) {
        showSuccess('Payment successful! Preparing download...');
        
        // Generate download link
        const downloadLink = await generateDownloadLink(beat);
        
        if (downloadLink) {
          // Open download link in new tab
          window.open(downloadLink, '_blank');
          showSuccess(`Download started for ${beat.title}!`);
        }
      }
      
      setLoading(false);
    }, 2000);
  };

  return {
    loading,
    checkPurchase,
    initiatePayPalPayment,
    generateDownloadLink,
  };
};