"use client";

import { useState } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { showSuccess, showError, showLoading } from '@/utils/toast';
import { supabase } from '@/lib/supabase';

interface Beat {
  id: string;
  title: string;
  price: number;
  audiourl: string;
  category: string;
  order: number;
}

export const usePayPal = () => {
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  // Asigură-te că acest URL este domeniul tău Vercel unde este deployat backend-ul
  const API_URL = 'https://cmbeats.com'; 

  const createPayPalOrder = async (beat: Beat) => {
    if (!user) {
      showError('Please log in to purchase');
      return null;
    }

    setLoading(true);
    showLoading('Creating PayPal order...');

    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        showError('Session expired. Please log in again.');
        setLoading(false);
        return null;
      }

      const response = await fetch(`${API_URL}/api/paypal/create-order`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${session.access_token}`,
        },
        mode: 'cors',
        body: JSON.stringify({
          beatId: beat.id,
          title: beat.title,
          price: beat.price,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        // Log the full error response from the server for better debugging
        console.error("Server response error:", data);
        if (data.availableKeys) {
          throw new Error(`Controller not found. Available keys: ${data.availableKeys.join(', ')}`);
        }
        throw new Error(data.error || 'Failed to create order');
      }

      showSuccess('Redirecting to PayPal...');
      setLoading(false);

      if (data.approvalUrl) {
        window.location.href = data.approvalUrl;
      }
      
      return data;

    } catch (error: any) {
      console.error('PayPal Order Error:', error);
      showError(error.message);
      setLoading(false);
      return null;
    }
  };

  const capturePayPalPayment = async (paymentId: string, payerId: string, purchaseId: string) => {
    setLoading(true);
    showLoading('Processing payment...');

    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        showError('Session expired');
        setLoading(false);
        return false;
      }

      const response = await fetch(`${API_URL}/api/paypal/capture`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${session.access_token}`,
        },
        mode: 'cors',
        body: JSON.stringify({ paymentId, payerId, purchaseId }),
      });

      const data = await response.json();
      if (!response.ok) {
        console.error("Server response error:", data);
        throw new Error(data.error || 'Failed to capture payment');
      }

      showSuccess('Payment successful!');
      setLoading(false);
      return true;
    } catch (error: any) {
      console.error('Capture Error:', error);
      showError(error.message);
      setLoading(false);
      return false;
    }
  };

  const getDownloadLink = async (beatId: string) => {
    if (!user) return null;
    setLoading(true);
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) return null;

      const response = await fetch(`${API_URL}/api/download/generate`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${session.access_token}`,
        },
        mode: 'cors',
        body: JSON.stringify({ beatId }),
      });

      const data = await response.json();
      if (!response.ok) {
        console.error("Server response error:", data);
        throw new Error(data.error || 'Failed to get download link');
      }
      setLoading(false);
      return data.downloadUrl;
    } catch (error: any) {
      console.error('Download Link Error:', error);
      showError(error.message);
      setLoading(false);
      return null;
    }
  };

  const checkPurchase = async (beatId: string): Promise<boolean> => {
    if (!user) return false;
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) return false;

      const response = await fetch(`${API_URL}/api/purchases/${beatId}`, {
        headers: { 
          'Authorization': `Bearer ${session.access_token}`,
          'Content-Type': 'application/json'
        },
        mode: 'cors'
      });

      if (!response.ok) {
        // Log the error response if not OK
        const errorData = await response.json().catch(() => ({ message: 'Could not parse error response' }));
        console.error("Server response error for checkPurchase:", response.status, errorData);
        return false;
      }
      const data = await response.json();
      return data.hasPurchased;
    } catch (error) {
      console.error("Error checking purchase:", error);
      return false;
    }
  }

  return { loading, createPayPalOrder, capturePayPalPayment, getDownloadLink, checkPurchase };
};