import { createClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://zrbeojjlnqkvzenqorcr.supabase.co';
const supabaseAnonKey = 'sb_publishable_k326Vv9qdXrmBRHfnS94xQ_LtbVQB5q';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);