"use client";

import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Music, User, ShoppingCart, LayoutDashboard, LogOut } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/hooks/useAuth';

const Navbar = () => {
  const navigate = useNavigate();
  const { user, signOut } = useAuth();

  const handleLogout = async () => {
    await signOut();
    navigate('/');
  };

  const isAdmin = user?.email === 'calin_moraru@yahoo.com';

  return (
    <nav className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 sticky top-0 z-50">
      <div className="container flex h-16 items-center justify-between">
        <div className="flex items-center gap-6 md:gap-10">
          <Link 
            to="/" 
            className="flex items-center space-x-2 transition-transform hover:scale-105 active:scale-95"
          >
            <div className="relative">
              <Music className="h-7 w-7 text-indigo-500" />
              <div className="absolute -bottom-1 -right-1 flex gap-[1px]">
                <div className="w-1.5 h-1.5 rounded-full bg-blue-500" />
                <div className="w-1.5 h-1.5 rounded-full bg-indigo-600" />
                <div className="w-1.5 h-1.5 rounded-full bg-pink-500" />
              </div>
            </div>
            <span className="inline-block font-black text-2xl tracking-tighter bg-gradient-to-r from-blue-500 via-indigo-600 to-pink-500 bg-clip-text text-transparent">
              CM BEATS
            </span>
          </Link>
        </div>
        <div className="flex items-center gap-4">
          {isAdmin && (
            <Link to="/admin">
              <Button variant="ghost" size="icon" title="Admin Dashboard">
                <LayoutDashboard className="h-5 w-5" />
              </Button>
            </Link>
          )}
          <Button variant="ghost" size="icon">
            <ShoppingCart className="h-5 w-5" />
          </Button>
          
          {user ? (
            <div className="flex items-center gap-2">
              <span className="hidden sm:inline text-sm text-muted-foreground">
                {user.email?.split('@')[0]}
              </span>
              <Button variant="outline" size="sm" onClick={handleLogout} className="gap-2">
                <LogOut className="h-4 w-4" />
                Logout
              </Button>
            </div>
          ) : (
            <Link to="/login">
              <Button variant="outline" className="hidden sm:flex items-center gap-2">
                <User className="h-4 w-4" />
                Sign In
              </Button>
            </Link>
          )}
        </div>
      </div>
    </nav>
  );
};

export default Navbar;