"use client";

import React, { useState, useEffect, useRef } from 'react';
import { Play, Pause } from 'lucide-react';
import { Button } from '@/components/ui/button';
import PurchaseButton from './PurchaseButton';
import WaveSurfer from 'wavesurfer.js';
import { showSuccess } from '@/utils/toast';

interface Beat {
  id: string;
  title: string;
  producer: string;
  category: string;
  price: number;
  cover: string | null;
  audiourl: string;
  order: number;
}

interface BeatListItemProps {
  beat: Beat;
}

const BeatListItem = ({ beat }: BeatListItemProps) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const waveformRef = useRef<HTMLDivElement>(null);
  const wavesurferRef = useRef<WaveSurfer | null>(null);

  useEffect(() => {
    if (!waveformRef.current) return;

    let isDestroyed = false;

    const wavesurfer = WaveSurfer.create({
      container: waveformRef.current,
      waveColor: '#94a3b8',
      progressColor: '#3b82f6',
      cursorColor: '#3b82f6',
      barWidth: 2,
      barRadius: 2,
      cursorWidth: 1,
      height: 40,
      barGap: 2,
      normalize: true,
      fillParent: true,
    });

    wavesurferRef.current = wavesurfer;

    if (!isDestroyed) {
      wavesurfer.load(beat.audiourl).catch(err => {
        if (err.name !== 'AbortError') {
          console.error('WaveSurfer load error:', err);
        }
      });
    }

    wavesurfer.on('ready', () => {
      if (!isDestroyed) {
        setDuration(wavesurfer.getDuration());
      }
    });

    wavesurfer.on('audioprocess', () => {
      if (isDestroyed) return;
      const time = wavesurfer.getCurrentTime();
      setCurrentTime(time);
      
      if (time >= 15) {
        wavesurfer.pause();
        wavesurfer.seekTo(0);
        setIsPlaying(false);
        showSuccess("Preview limit reached (15s). Purchase to hear the full beat!");
      }
    });

    wavesurfer.on('finish', () => setIsPlaying(false));
    wavesurfer.on('play', () => setIsPlaying(true));
    wavesurfer.on('pause', () => setIsPlaying(false));

    return () => {
      isDestroyed = true;
      if (wavesurferRef.current) {
        wavesurferRef.current.destroy();
        wavesurferRef.current = null;
      }
    };
  }, [beat.audiourl]);

  const togglePlay = () => {
    if (wavesurferRef.current) {
      wavesurferRef.current.playPause();
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  // Optimize placeholder images
  const imageUrl = beat.cover 
    ? (beat.cover.includes('unsplash.com') ? `${beat.cover.split('?')[0]}?w=150&q=70` : beat.cover)
    : 'https://images.unsplash.com/photo-1614613535308-eb5fbd3d2c17?w=150&q=70';

  return (
    <div className="flex flex-col sm:flex-row items-center gap-4 p-4 rounded-lg border bg-card hover:bg-accent/50 transition-colors">
      <div className="relative group shrink-0">
        <img 
          src={imageUrl} 
          alt={beat.title} 
          loading="lazy"
          className="w-16 h-16 rounded object-cover"
        />
        <button 
          onClick={togglePlay}
          className="absolute inset-0 flex items-center justify-center bg-primary/80 opacity-0 group-hover:opacity-100 transition-opacity rounded"
        >
          {isPlaying ? (
            <Pause className="h-6 w-6 text-primary-foreground fill-current" />
          ) : (
            <Play className="h-6 w-6 text-primary-foreground fill-current" />
          )}
        </button>
      </div>

      <div className="flex-1 flex flex-col gap-1 min-w-0">
        <div>
          <h4 className="font-bold truncate">{beat.title}</h4>
          <p className="text-sm text-muted-foreground truncate">prod. {beat.producer}</p>
        </div>
        <div className="flex flex-col gap-1 w-full">
          <div ref={waveformRef} className="w-full" />
          <div className="flex justify-between text-xs font-mono text-muted-foreground">
            <span>{formatTime(currentTime)}</span>
            <span>0:15</span>
          </div>
        </div>
      </div>

      <div className="flex items-center gap-3 shrink-0">
        <span className="font-mono font-bold text-lg">${beat.price}</span>
        <PurchaseButton beat={beat} />
      </div>
    </div>
  );
};

export default BeatListItem;