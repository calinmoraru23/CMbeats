"use client";

import React from 'react';
import { cn } from "@/lib/utils";

const WaveformIcon = ({ active = false }: { active?: boolean }) => {
  return (
    <div className="flex items-center gap-[2px] h-8 w-full max-w-[200px]">
      {[...Array(20)].map((_, i) => {
        const height = Math.random() * 100;
        return (
          <div 
            key={i}
            className={cn(
              "w-1 rounded-full transition-all duration-300",
              active ? "bg-primary" : "bg-muted-foreground/30"
            )}
            style={{ 
              height: `${Math.max(20, height)}%`,
              animationDelay: `${i * 0.05}s`
            }}
          />
        );
      })}
    </div>
  );
};

export default WaveformIcon;