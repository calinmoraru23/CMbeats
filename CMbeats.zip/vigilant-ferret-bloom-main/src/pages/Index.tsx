"use client";

import React, { useState, useEffect, useRef } from 'react';
import { useSearchParams } from 'react-router-dom';
import Navbar from '@/components/Navbar';
import CategoryCard from '@/components/CategoryCard';
import BeatListItem from '@/components/BeatListItem';
import { Button } from '@/components/ui/button';
import { ChevronLeft, Search, Loader2 } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { supabase } from '@/lib/supabase';
import { showError } from '@/utils/toast';

interface Beat {
  id: string;
  title: string;
  producer: string;
  category: string;
  price: number;
  cover: string | null;
  audiourl: string;
  order: number;
}

interface Category {
  id: string;
  name: string;
  image_url: string | null;
  order_index: number;
}

const Index = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const selectedCategory = searchParams.get('category');
  
  const [categories, setCategories] = useState<Category[]>([]);
  const [loadingCategories, setLoadingCategories] = useState(true);
  const [beats, setBeats] = useState<Beat[]>([]);
  const [loadingBeats, setLoadingBeats] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  
  // Ref for scroll position
  const scrollPosRef = useRef<number>(0);

  // Fetch categories from Supabase
  useEffect(() => {
    const fetchCategories = async () => {
      setLoadingCategories(true);
      const { data, error } = await supabase
        .from('categories')
        .select('*')
        .order('order_index', { ascending: true });

      if (error) {
        showError('Failed to fetch categories: ' + error.message);
        setCategories([]);
      } else {
        setCategories(data || []);
      }
      setLoadingCategories(false);
    };

    fetchCategories();
  }, []);

  // Fetch beats from Supabase
  useEffect(() => {
    const fetchBeats = async () => {
      setLoadingBeats(true);
      let query = supabase
        .from('beats')
        .select('*')
        .order('order', { ascending: true });

      if (selectedCategory) {
        query = query.eq('category', selectedCategory);
      }

      const { data, error } = await query;

      if (error) {
        showError('Failed to fetch beats: ' + error.message);
        setBeats([]);
      } else {
        setBeats(data || []);
      }
      setLoadingBeats(false);
    };

    fetchBeats();

    // Scroll to top when a category is selected
    if (selectedCategory) {
      window.scrollTo(0, 0);
    }
  }, [selectedCategory]);

  // Handle scroll restoration when returning to categories list
  useEffect(() => {
    if (!selectedCategory && scrollPosRef.current > 0) {
      // Small timeout to ensure categories are rendered before scrolling
      const timer = setTimeout(() => {
        window.scrollTo({
          top: scrollPosRef.current,
          behavior: 'instant'
        });
      }, 50);
      return () => clearTimeout(timer);
    }
  }, [selectedCategory, loadingCategories]);

  const filteredBeats = beats.filter(beat => 
    beat.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    beat.producer.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleCategorySelect = (categoryName: string) => {
    // Save current scroll position before entering category
    scrollPosRef.current = window.scrollY;
    setSearchParams({ category: categoryName });
  };

  const handleBackToCategories = () => {
    setSearchParams({});
    setSearchTerm('');
  };

  return (
    <div className="min-h-screen bg-background pb-8">
      <Navbar />
      
      {!selectedCategory ? (
        <main className="container py-12 px-4 animate-in fade-in duration-500">
          <div className="text-center mb-16 space-y-4">
            <h1 className="text-5xl md:text-8xl font-black tracking-tighter italic">
              <span className="bg-gradient-to-r from-blue-500 via-indigo-600 to-pink-500 bg-clip-text text-transparent">
                FIND YOUR SOUND
              </span>
            </h1>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto font-medium">
              Explore high-performance beats crafted for your next hit.
            </p>
          </div>

          {loadingCategories ? (
            <div className="flex justify-center py-8">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : categories.length === 0 ? (
            <p className="text-center text-muted-foreground py-8">
              No categories found. Please add some from the admin dashboard.
            </p>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {categories.map((cat) => (
                <CategoryCard 
                  key={cat.id}
                  name={cat.name}
                  image={cat.image_url || 'https://images.unsplash.com/photo-1571609832127-401c56ee628a?w=800'}
                  onClick={() => handleCategorySelect(cat.name)}
                />
              ))}
            </div>
          )}
        </main>
      ) : (
        <main className="container py-12 px-4 animate-in slide-in-from-right duration-500">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-12">
            <div className="flex items-center gap-4">
              <Button 
                variant="outline" 
                size="icon" 
                onClick={handleBackToCategories}
              >
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <h1 className="text-4xl font-bold tracking-tight">{selectedCategory} Beats</h1>
            </div>
            
            <div className="relative max-w-sm w-full">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input 
                placeholder="Search in this category..." 
                className="pl-10" 
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </div>

          <div className="space-y-4">
            <h2 className="text-lg font-semibold text-muted-foreground mb-4">Recently Uploaded</h2>
            {loadingBeats ? (
              <div className="flex justify-center py-8">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : filteredBeats.length === 0 ? (
              <p className="text-center text-muted-foreground py-8">
                No beats found in this category.
              </p>
            ) : (
              filteredBeats.map((beat) => (
                <BeatListItem 
                  key={beat.id}
                  beat={beat}
                />
              ))
            )}
          </div>
        </main>
      )}
    </div>
  );
};

export default Index;