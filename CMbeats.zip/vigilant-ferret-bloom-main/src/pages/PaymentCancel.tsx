"use client";

import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { XCircle } from 'lucide-react';

const PaymentCancel = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <XCircle className="h-12 w-12 mx-auto text-orange-500 mb-4" />
          <CardTitle className="text-2xl">Payment Cancelled</CardTitle>
        </CardHeader>
        
        <CardContent className="text-center space-y-4">
          <p className="text-muted-foreground">
            You cancelled the payment process. Your beat has not been licensed.
          </p>
          <div className="flex gap-2">
            <Button 
              onClick={() => navigate('/')}
              className="w-full"
            >
              Back to Beats
            </Button>
            <Button 
              variant="outline"
              onClick={() => navigate('/admin')}
              className="w-full"
            >
              Try Again
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default PaymentCancel;