import { supabaseAdmin } from './supabaseAdmin.js';

export const verifyToken = async (req, res, next) => {
  console.log("Auth middleware: Verifying token...");

  if (!supabaseAdmin) {
    console.error("Auth middleware: Supabase admin client is not initialized. Cannot verify token.");
    return res.status(500).json({ error: 'Server configuration error: Supabase client not available. Check server logs for environment variable issues.' });
  }

  const authHeader = req.headers.authorization;

  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    console.warn("Auth middleware: No or invalid Authorization header.");
    return res.status(401).json({ error: 'Authorization token required.' });
  }

  const token = authHeader.split(' ')[1];

  try {
    const { data: { user }, error } = await supabaseAdmin.auth.getUser(token);

    if (error || !user) {
      console.error("Auth middleware: Token verification failed.", error?.message);
      return res.status(401).json({ error: 'Invalid or expired token.' });
    }

    req.user = user;
    console.log("Auth middleware: Token verified for user:", user.id);
    next();
  } catch (error) {
    console.error("Auth middleware: Unexpected error during token verification:", error);
    return res.status(500).json({ error: 'Internal server error during authentication.' });
  }
};