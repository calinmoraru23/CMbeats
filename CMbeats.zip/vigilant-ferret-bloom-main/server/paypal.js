import paypal from '@paypal/paypal-server-sdk';

const { PAYPAL_CLIENT_ID, PAYPAL_CLIENT_SECRET, PAYPAL_MODE } = process.env;

console.log("PayPal module loaded.");
console.log("PAYPAL_CLIENT_ID (in paypal.js):", PAYPAL_CLIENT_ID ? "SET" : "NOT SET");
console.log("PAYPAL_CLIENT_SECRET (in paypal.js):", PAYPAL_CLIENT_SECRET ? "SET" : "NOT SET");
console.log("PAYPAL_MODE (in paypal.js):", PAYPAL_MODE || "NOT SET");

let client = null;

if (!PAYPAL_CLIENT_ID || !PAYPAL_CLIENT_SECRET || !PAYPAL_MODE) {
  console.error("PayPal environment variables are NOT set. PayPal client will not be initialized.");
} else {
  try {
    const environment = PAYPAL_MODE === 'live' 
      ? new paypal.core.LiveEnvironment(PAYPAL_CLIENT_ID, PAYPAL_CLIENT_SECRET)
      : new paypal.core.SandboxEnvironment(PAYPAL_CLIENT_ID, PAYPAL_CLIENT_SECRET);
    client = new paypal.core.PayPalHttpClient(environment);
    console.log("PayPal client initialized successfully.");
  } catch (e) {
    console.error("Error initializing PayPal client:", e.message);
    client = null; // Ensure client is null on error
  }
}

export const createOrder = async (amount, description, purchaseId) => {
  console.log("createOrder called. PayPal client status:", client ? "INITIALIZED" : "NOT INITIALIZED");
  if (!client) {
    console.error("Attempted to create PayPal order, but client is not initialized.");
    throw new Error("PayPal service is not available. Check server logs for environment variable errors.");
  }
  const request = new paypal.orders.OrdersCreateRequest();
  request.prefer("return=representation");
  request.requestBody({
    intent: "CAPTURE",
    purchase_units: [
      {
        amount: {
          currency_code: "USD",
          value: amount.toFixed(2),
        },
        description: description,
        custom_id: purchaseId,
      },
    ],
    application_context: {
      return_url: "https://cmbeats.com/payment/success",
      cancel_url: "https://cmbeats.com/payment/cancel",
      shipping_preference: "NO_SHIPPING",
      user_action: "PAY_NOW",
    },
  });

  const response = await client.execute(request);
  return response.result;
};

export const capturePayment = async (orderId) => {
  console.log("capturePayment called. PayPal client status:", client ? "INITIALIZED" : "NOT INITIALIZED");
  if (!client) {
    console.error("Attempted to capture PayPal payment, but client is not initialized.");
    throw new Error("PayPal service is not available. Check server logs for environment variable errors.");
  }
  const request = new paypal.orders.OrdersCaptureRequest(orderId);
  request.prefer("return=representation");
  const response = await client.execute(request);
  return response.result;
};