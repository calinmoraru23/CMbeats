# CM Beats Backend

## Setup

1. Install dependencies:
```bash
npm install
```

2. Copy `.env.example` to `.env` and fill in:
   - PayPal Client ID & Secret (from PayPal Developer Dashboard)
   - Supabase Service Role Key (from Supabase Dashboard > Settings > API)

3. Start server:
```bash
npm run dev
```

## API Endpoints

- `POST /api/paypal/create-order` - Creare sesiune PayPal
- `POST /api/paypal/capture` - Capturare plată
- `POST /api/paypal/webhook` - Webhook PayPal
- `POST /api/download/generate` - Generare link download
- `GET /api/purchases/:beatId` - Verificare achiziție

## PayPal Setup

1. Create PayPal Developer App: https://developer.paypal.com/
2. Get Client ID & Secret
3. Configure Webhook URL: `https://yourdomain.com/api/paypal/webhook`
4. Subscribe to events: `PAYMENT.CAPTURE.COMPLETED`

## Supabase Setup

1. Create tables (SQL):
```sql
-- Purchases table
create table purchases (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references auth.users(id),
  beat_id text not null,
  amount numeric(10,2) not null,
  status text not null, -- pending, completed, failed
  paypal_payment_id text,
  created_at timestamp with time zone default now(),
  completed_at timestamp with time zone,
  webhook_verified boolean default false
);

-- Downloads table
create table downloads (
  id uuid default gen_random_uuid() primary key,
  purchase_id uuid references purchases(id),
  user_id uuid references auth.users(id),
  beat_id text not null,
  download_at timestamp with time zone default now()
);

-- Storage: beats bucket
-- Set RLS policies for private access
```

2. Enable Storage and create `beats` bucket
3. Upload WAV files as `private/{beat_id}.wav`